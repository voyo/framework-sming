This directory contains patches to upstream Arudino libraries.
